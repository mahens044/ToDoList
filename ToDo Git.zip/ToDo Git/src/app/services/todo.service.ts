import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {map, catchError} from 'rxjs/operators';
import { Todo } from '../models/Todo';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
}

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  // todosUrl:string = 'https://jsonplaceholder.typicode.com/todos';
  todosUrl:string='https://todolist-92e93.firebaseio.com/posts';
  todosLimit = '?_limit=5';
  todos:Todo[] =[];
  
  constructor(private http:HttpClient) { }

    // Add Todo
  addTodo(todo:Todo):Observable<Todo> {
    // this.todos.push(todo);
    // console.log(todo);
    
    return this.http.post<Todo>('https://todolist-92e93.firebaseio.com/posts.json', todo, httpOptions);
  }

  // Get Todos
  getTodos():Observable<Todo[]> {
    // return this.http.get<Todo[]>(`${this.todosUrl}${this.todosLimit}`);
    return this.http.get<Todo[]>(`https://todolist-92e93.firebaseio.com/posts.json`);
    // .pipe(
    //   map(todos => {
    //      return {
    //         ...todos          
    //     }
    //   }));
  }

  // Delete Todo
  deleteTodo(todo:Todo):Observable<Todo> {
    const url = `${this.todosUrl}/${todo.id}`;
    console.log("Id "+todo.id);
    return this.http.delete<Todo>(url, httpOptions);
  }

  

  // Toggle Completed
  toggleCompleted(todo: Todo):Observable<any> {
    const url = `${this.todosUrl}/${todo.id}`;
    return this.http.put(url, todo, httpOptions);
  }
}
